function __Styles(){
	pantographShapesFillColor = "#f2c885";
    pantographShapesStrokeColor = "#9b763d";
}
;
