/**
 * Created with JetBrains WebStorm.
 * User: yunus_work
 * Date: 13.09.2012
 * Time: 10:08
 * To change this template use File | Settings | File Templates.
 */


function __Languages(){

}
;
