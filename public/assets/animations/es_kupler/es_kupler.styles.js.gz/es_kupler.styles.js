function __Styles(){
	animationShapeStyle = {
        strokeColor:'#666',
        fillColor: new RgbColor(0.8,0.8,0.8,0.60)
    };
    interactionShapeStyle = {
        strokeColor:'#687',
        fillColor: new RgbColor(0.6,0.8,0.7,0.8)
    }

}
;
