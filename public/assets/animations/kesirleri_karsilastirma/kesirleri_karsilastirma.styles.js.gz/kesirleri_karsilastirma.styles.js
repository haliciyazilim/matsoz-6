function __Styles(){
    placeHolderColor = "#bfe8ef";
    fractionsColor="#e6c181";
    sortableCursorType="pointer";

    fractionsDivStyle = {
        position:'absolute',
        top:'30px',
        left:'150px',
        height:'40px',
        width:'180px',
//        border:'1px solid',
        fontSize:'16px',
        opacity:0
    };

    equalizedFractionsDivStyle = {
        position:'absolute',
        top:'30px',
        left:'470px',
        height:'40px',
        width:'180px',
//        border:'1px solid',
        fontSize:'16px'
    };

    fractionsOnAxisDivStyle = {
        position:'absolute',
        top:'152px',
        left:'244px',
        height:'40px',
        width:'380px',
//        border:'1px solid',
        fontSize:'16px'
    };

    informationsDivStyle = {
        position:'absolute',
        top:'70px',
        left:'100px',
        width:'540px',
        height:'60px',
//        border:'1px solid'
    };
}
;
