function __Styles(){
	outsideColor = new RgbColor(0.953,0.784,0.518);
    insideColor = new RgbColor(0.663,0.859,0.898);

    insideColor2 = new RgbColor(0.255,0.506,0.541);
    outsideColor2 = new RgbColor(0.451,0.467,0.239);
}
;
