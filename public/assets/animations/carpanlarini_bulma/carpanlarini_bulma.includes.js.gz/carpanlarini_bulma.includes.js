//= require ./carpanlarini_bulma.styles.js
//= require ./carpanlarini_bulma.common.js
//= require ./carpanlarini_bulma.animation.js
//= require ./carpanlarini_bulma.interaction.js
;