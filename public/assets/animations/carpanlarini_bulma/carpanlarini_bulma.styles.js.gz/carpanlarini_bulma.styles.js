function __Styles(){
    animationEqsColor = "green";
    wholeFactorsColor = "#069"
}
;
