function __Styles(){

    animDivStyle = {
        position:'absolute',
        top:'40px',
        left:'330px',
        width:'150px',
        height:'80px',
        fontSize:'32px'
    };

    questionDivStyle = {
        position:'absolute',
        top:'60px',
        left:'160px',
        width:'200px',
        height:'60px',
        fontSize:'32px'
    };

    answerDivStyle = {
        position:'absolute',
        top:'160px',
        left:'80px',
        width:'360px',
        height:'30px',
        fontSize:'24px',
        color:'#069',
        textAlign:'center',
    //    border:'1px solid'
    }

};
