function __Styles(){
	colors = [];

    colors[0] = "#dcdd89";
    colors[1] = "#d397f0";
    colors[2] = "#9ee9a5";
    colors[3] = "#e99e9e";
    colors[4] = "#a8dbe3";
    colors[5] = "#f2c885";

    rgbColors = [];
    rgbColors[0] = new RgbColor(0.863,0.867,0.537);
    rgbColors[1] = new RgbColor(0.827,0.592,0.941);
    rgbColors[2] = new RgbColor(0.620,0.914,0.647);
    rgbColors[3] = new RgbColor(0.914,0.620,0.620);
    rgbColors[4] = new RgbColor(0.659,0.859,0.890);
    rgbColors[5] = new RgbColor(0.949,0.784,0.522);

}
;
