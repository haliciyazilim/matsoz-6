//= require ./ataturk_ve_matematik.styles.js
//= require ./ataturk_ve_matematik.common.js
//= require ./ataturk_ve_matematik.animation.js
//= require ./ataturk_ve_matematik.interaction.js 
;