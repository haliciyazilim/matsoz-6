function __Styles(){

    setDivCss = {
        position:'absolute',
        left:'50px',
        fontSize:'16px',
        width:'400px',
        lineHeight:'20px'


    }

    answerSetDivCss = {
        position: 'absolute',
        top:'100px',
        left:'50px',
        fontSize:'16px'
    }
}
;
