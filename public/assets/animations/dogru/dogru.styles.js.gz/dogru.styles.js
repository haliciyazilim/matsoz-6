function __Styles(){

    firstCircleColor = "#ffde00";
    secondCircleColor = "#0072ff";
    thirdCircleColor = "#e0a26f";
    fourthCircleColor = "#7fae4e";
    fifthCircleColor = "#df5353";

    lettersStyle = {
        position:'absolute',
        top:'76px',
        left:'242px',
        width:'308px',
        height:'60px',
        fontSize:'28px',
        textAlign:'center',
        opacity:0
    //    border:'1px solid'
    };

    letters2Style = {
        position:'absolute',
        top:'150px',
        left:'242px',
        width:'308px',
        height:'30px',
        fontSize:'24px',
        textAlign:'center',
        opacity:0
    //    border:'1px solid'
    };

}
;
