//= require ../benzer_cokgenler/benzer_cokgenler.common.js
//= require ./yuzey_alani.styles.js
//= require ./yuzey_alani.common.js
//= require ./yuzey_alani.animation.js
//= require ./yuzey_alani.interaction.js 
;