function __Styles(){
	ilkRenk="#000000";
    degisenRenk="#ff0000"
}
;
