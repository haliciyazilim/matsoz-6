function __Styles(){
    rectFillColor = "#ffdead";

    questionDivStyle = {
        position:'absolute',
        top:'40px',
        left:'120px',
        width:'300px',
        height:'60px',
        fontSize:'24px'
    };

    answerDivStyle = {
        position:'absolute',
        top:'130px',
        left:'172px',
        width:'400px',
        height:'80px',
        fontSize:'18px',
//        border:'1px solid',
        color:'#069'
    };

    firstShapeStrokeColor = "#9b763d";
    firstShapeFillColor = "#f2c885";

    secondShapeLastColor = "#4f9c4f";
    secondShapeFillColor = "#9ee9a5";

    firstTextStyle = {
        position:'absolute',
        top:'40px',
        left:'100px',
        width:'240px',
        height:'40px',
    //    border:'1px solid',
        fontSize:'16px',
        opacity:0
    };

    firstSolutionStyle = {
        position:'absolute',
        top:'120px',
        left:'146px',
        width:'150px',
        height:'40px',
    //    border:'1px solid',
        fontSize:'16px'
    };

    secondTextStyle = {
        position:'absolute',
        top:'30px',
        left:'450px',
        width:'240px',
        height:'40px',
//        border:'1px solid',
        fontSize:'16px',
        opacity:0
    };

    secondSolutionStyle = {
        position:'absolute',
        top:'130px',
        left:'470px',
        width:'150px',
        height:'40px',
//        border:'1px solid',
        fontSize:'16px'
    };
}
;
