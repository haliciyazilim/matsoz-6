function __Styles(){
	questionDivStyle = {
        position:'absolute',
        top:'20px',
        left:'80px',
        width:'440px',
        height:'100px',
    //    border:'1px solid',
        fontSize:'32px'
    };

    answerDivStyle = {
        position:'absolute',
        top:'120px',
        left:'30px',
        width:'500px',
        height:'60px',
    //    border:'1px solid',
        color:'#069',
        fontSize:'20px',
        opacity:0
    };

    firstDivStyle = {
        position:'absolute',
        top:'26px',
        left:'260px',
        width:'80px',
        height:'150px',
    //    border:'1px solid',
        fontSize:'24px'
    };

    secondDivStyle = {
        position:'absolute',
        top:'110px',
        left:'440px',
        width:'200px',
        height:'70px',
    //    border:'1px solid',
        fontSize:'24px'
    };
}
;
