function __Styles(){
    animTop=50;
    animLeft=384;
}
;
