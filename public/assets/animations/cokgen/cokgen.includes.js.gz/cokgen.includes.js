//= require ./cokgen.styles.js
//= require ./cokgen.common.js
//= require ./cokgen.animation.js
//= require ./cokgen.interaction.js 
;