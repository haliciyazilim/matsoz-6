function __Styles(){
    shapeStyle = {strokeColor:'#255b63',strokeWidth:2,fillColor:new RgbColor(1,1,1,0)};

    textStyle = {fontSize:13,fillColor:'#fff',justification:'center'};
    edgeStyle = {'stroke-width':'2px'};
    angleStyle = {'fill':'#DDD'};
    animationEdgeStyle = {strokeColor:'#000',strokeWidth:2}

    dropableShapeHoverStyle = {strokeColor:'#000',fillColor:'#dd9',strokeWidth:2};
    dropableShapeDefaultStyle = "default"//shadow
    dropableShapeDefaultTriangleStyle = {strokeColor:'#999',fillColor:'rgb(146,208,80)',strokeWidth:1};
    dropableShapeDefaultRectangleStyle = {strokeColor:'#999',fillColor:'rgb(226,108,9)',strokeWidth:1};
    dropableShapeDefaultPentagonStyle = {strokeColor:'#999',fillColor:'rgb(177,160,198)',strokeWidth:1};
    dropableShapeDefaultHexagonStyle = {strokeColor:'#999',fillColor:'rgb(217,148,147)',strokeWidth:1};
    dropableShapeDroppedTrueStyle = {strokeColor:'#0f0',fillColor:'#afa'};
    dropableShapeDroppedFalseStyle = {strokeColor:'#f00',fillColor:'#f00'};

}
;
