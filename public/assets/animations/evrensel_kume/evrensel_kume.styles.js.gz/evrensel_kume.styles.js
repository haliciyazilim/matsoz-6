function __Styles(){
    animationDotStyle = {
        strokeColor:'#fff',
        strokeWidth:2,
        fillColor:'#000'
    };
    animationEdgeStyle = {
        strokeColor:'#000',
        strokeWidth:2
    };
    animationTextStyle = {
        fontSize:18,
        strokeWidth:1,
        strokeColor:"#000"
    }

}
;
