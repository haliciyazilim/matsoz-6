//= require ./ondalik_kesirleri_karsilastirma.styles.js
//= require ./ondalik_kesirleri_karsilastirma.common.js
//= require ./ondalik_kesirleri_karsilastirma.animation.js
//= require ./ondalik_kesirleri_karsilastirma.interaction.js 
;