function __Styles(){
    tabloStrokeRenk="#255b63";
    tabloBirlerFillRenk="#ecf8fa";
    tabloBinlerFillRenk="#d9f1f5";
    tabloMilyonlarFillRenk="#bfe8ef";
    inputStrokeRenk="#9bd1d9";

    sayilarKutuRenk="#e6c181";
    sayilarKutuStrokeRenk="#4f360b";
    sayilarStrokeRenk="#4f360b";
    yerTutucuRenk="#F2F2F2";
}
;
