function __Styles(){
    wholeTableFillColor = "white";
    wholeTableStrokeColor = "#a8dbe3";

    wholeTablePrimeFillColor = "#9ee9a5";
    wholeTablePrimeStrokeColor = "#4f9c4f";

    counterColor = "#a8dbe3";
    counterQuestionColor = "#41818a"

    animationRectFillColor = "e99e9e";
    animationRectStrokeColor = "9c4f4f"

    animationRectFillColor2 = "f2c885";
    animationRectStrokeColor2 = "9b763d";

    textColor = "#006e7d";
    textColor2 = "#FF0000"; // not divisible color
    textColor3 = "#000000"; // original color
    textColor4 = "#006e7d" // divisible color
}
;
