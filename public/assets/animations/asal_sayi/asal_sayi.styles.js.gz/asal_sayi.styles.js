function __Styles(){
    wholeTableFillColor = "white";
    wholeTableStrokeColor = "#a8dbe3";

    wholeTablePrimeFillColor = "#9ee9a5";
    wholeTablePrimeStrokeColor = "#4f9c4f";

    counterColor = "#a8dbe3";

    animationRectFillColor = "e99e9e";
    animationRectStrokeColor = "9c4f4f"

    animationRectFillColor2 = "f2c885";
    animationRectStrokeColor2 = "9b763d"
}
;
