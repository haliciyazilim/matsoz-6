function __Styles(){
    answerDivColor = "#069";
    animColor = "#ff0000";
}
;
