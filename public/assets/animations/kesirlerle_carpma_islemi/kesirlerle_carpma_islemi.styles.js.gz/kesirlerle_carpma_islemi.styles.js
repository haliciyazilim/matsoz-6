function __Styles(){
	firstTextCss = {
        position:'absolute',
        top:'40px',
        left:'190px',
        height:'60px',
        width:'230px',
        fontSize:'16px',
        opacity:0
    };

    firstSolutionCss = {
        position:'absolute',
        top:'110px',
        left:'190px',
        height:'50px',
        width:'220px',
        fontSize:'16px'
    };

    secondTextCss = {
        position:'absolute',
        top:'40px',
        left:'480px',
        height:'30px',
        width:'200px',
        fontSize:'16px',
        opacity:0
    };

    secondSolutionCss = {
        position:'absolute',
        top:'130px',
        left:'480px',
        height:'50px',
        width:'220px',
        fontSize:'16px'
    };

    circFillColor = "#e99e9e";

    rectFillColor = "#e99e9e";
    rectFillColor2 = "#9c4f4f";

    interactionRectStrokeColor = "#41818a";
    interactionRectFillColor = "#a8dbe3";

    firstFracStyle = {
        position:'absolute',
        top:'120px',
        left:'40px',
        width:'100px',
        height:'60px',
//        border:'1px solid',
        fontSize:'20px'
    };

    secondFracStyle = {
        position:'absolute',
        top:'40px',
        left:'160px',
        width:'100px',
        height:'60px',
//        border:'1px solid',
        fontSize:'20px'
    };

    answerDivStyle = {
        position:'absolute',
        top:'150px',
        left:'135px',
        width:'400px',
        height:'80px',
        fontSize:'18px',
        //    border:'1px solid',
        color:'#069'
    };

    questionDivStyle = {
        position:'absolute',
        top:'40px',
        left:'120px',
        width:'300px',
        height:'60px',
        fontSize:'24px'
    };
}
;
