function __Styles(){

    questionDivStyle = {
        position:'absolute',
        top:'30px',
        left:'80px',
        width:'400px',
        height:'80px',
        fontSize:'30px'
    };

    answerDivStyle = {
        position:'absolute',
        top:'160px',
        left:'10px',
        width:'510px',
        height:'40px',
        color:'#069',
        fontSize:'22px',
        textAlign:'center',
        lineHeight:'24px',
        opacity:0
    };

    animDivStyle = {
        position:'absolute',
        top:'40px',
        left:'200px',
        width:'400px',
        height:'140px',
        fontSize:'32px'
    };
}
;
