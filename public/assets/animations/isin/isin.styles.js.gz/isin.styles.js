function __Styles(){
    lettersStyle = {
        position:'absolute',
        top:'76px',
        left:'242px',
        width:'308px',
        height:'60px',
        fontSize:'28px',
        textAlign:'center',
        opacity:0
    };

    letters2Style = {
        position:'absolute',
        top:'150px',
        left:'242px',
        width:'308px',
        height:'30px',
        fontSize:'24px',
        textAlign:'center',
        opacity:0
        //    border:'1px solid'
    };

    pencilStyle = {
        position:'absolute',
        top:'-45px',
        left:'250px',
        opacity:0
    }
}
;
