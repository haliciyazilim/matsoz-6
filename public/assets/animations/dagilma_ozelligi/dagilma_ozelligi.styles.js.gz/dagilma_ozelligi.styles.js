function __Styles(){
	/*
	* write your styles here without using 'var' definer
	*/
}
;
