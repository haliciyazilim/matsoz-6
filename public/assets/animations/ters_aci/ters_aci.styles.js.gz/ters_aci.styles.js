function __Styles(){
//    Angle.RADIUS = 145;
    OppositeAngles.letterTextStyle = {
        fontSize:14
    }
}
;
