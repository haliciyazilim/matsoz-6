function __Styles(){
    animationFirstFillColor = "#F2C885";
    animationFirstStrokeColor = "#9B763D";
    animationSecondFillColor = "#E99E9E";
    animationSecondStrokeColor = "#9C4F4F";


    interactionFillColors = [];
    interactionFillColors[0] = "#ff4e4e";
    interactionFillColors[1] = "#ffa443";
    interactionFillColors[2] = "#ff54ff";
    interactionFillColors[3] = "#499745";
    interactionFillColors[4] = "#5050fd";
    interactionFillColors[5] = "#ffffff";
    interactionFillColors[6] = "#57ee57";
    interactionFillColors[7] = "#7348a9";
    interactionFillColors[8] = "#ffff51";
    interactionFillColors[9] = "#727272";

}
;
