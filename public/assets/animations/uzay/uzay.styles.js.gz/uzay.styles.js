function __Styles(){
	strokeColor = "#9b763d";
    fillColor = "#f2c885";

    lineStyle = {
        strokeWidth:2,
        strokeColor:strokeColor
    };

    circStyle = {
        fillColor:fillColor,
        strokeColor:strokeColor
    };

    fillStyle = {
        fillColor:fillColor,
        strokeColor:strokeColor
    };

    interactionRectanglePrisimStyle = {
        strokeColor: "#000"
    }
}
;
