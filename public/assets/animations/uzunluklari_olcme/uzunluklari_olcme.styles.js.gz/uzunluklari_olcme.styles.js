function __Styles(){
    animStrokeColors = "#000000";

    meterColor = "#ff0000";
    decimeterColor = "#ff6666";
    centimeterColor = "#ff9999";
    millimeterColor = "#ffcccc";
    decameterColor = "#990000";
    hectometerColor = "#66000";
    kilometerColor = "#33000";

    questionDivStyle = {
        position:'absolute',
        top:'80px',
        left:'120px',
        width:'340px',
        height:'60px',
        fontSize:'24px'
    }
};
