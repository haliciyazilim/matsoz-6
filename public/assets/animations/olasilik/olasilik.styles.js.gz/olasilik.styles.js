function __Styles(){
    ballColors = [];
    ballColors[0] = "#ff0000";      // kırmızı
    ballColors[1] = "#0096ff";      // mavi
    ballColors[2] = "#ff9900";      // turuncu
    ballColors[3] = "#00c800";      // yeşil

    questionDivStyle = {
        position:'absolute',
        top:'100px',
        left:'260px',
        height:'100px',
        width:'320px'
    };

    questionTextStyle = {
        position:'absolute',
        top:'30px',
        left:'-10px',
        width:'250px',
        height:'20px',
        fontSize:'18px',
        textAlign:'right'
    };

    lineStyle = {
        position:'absolute',
        height:'1px',
        width:'38px',
        padding:0,
        borderTop:'1px solid',
        top:'38px',
        left:'248px'
    };

    animationDivStyle = {
        position:'absolute',
        top:'30px',
        left:'30px',
        height:'160px',
        width:'700px',
        verticalAlign:'middle'
    };

    firstDivStyle = {
        position:'absolute',
        top:'10px',
        left:'100px',
        height:'60px',
        width:'500px',
        fontSize:'18px'
    };

    secondDivStyle = {
        position:'absolute',
        top:'80px',
        left:'160px',
        height:'60px',
        width:'410px',
        fontSize:'18px'
    };
};
