//= require ./degisme_ozelligi.styles.js
//= require ./degisme_ozelligi.common.js
//= require ./degisme_ozelligi.animation.js
//= require ./degisme_ozelligi.interaction.js
;