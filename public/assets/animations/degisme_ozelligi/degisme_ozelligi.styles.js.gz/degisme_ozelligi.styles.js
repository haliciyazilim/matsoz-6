function __Styles(){
	operatorFillColor = "#c00000";
    operatorTextColor = "white"; // do bold
    operandBoxesFillColor = "#41818a";
    operandTextColor = "white"; // do bold
    generalStrokeColor = "#101010";

    disabledInputBackgroundColor = "#006e7d";
    disabledInputOpacity = 0.3;

    selectedInputStrokeColor = "#006e7d";
    selectedInputStrokeWidth = 2; // try this

    // selectedInput "border-style", "inset" -> try this also
}
;
