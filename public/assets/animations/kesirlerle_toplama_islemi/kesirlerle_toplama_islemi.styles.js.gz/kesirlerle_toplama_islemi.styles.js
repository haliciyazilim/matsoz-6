function __Styles(){
	rectFillColor = "#ffdead";

    questionDivStyle = {
        position:'absolute',
        top:'40px',
        left:'120px',
        width:'300px',
        height:'60px',
        fontSize:'24px'
    };

    answerDivStyle = {
        position:'absolute',
        top:'130px',
        left:'105px',
        width:'400px',
        height:'80px',
        fontSize:'18px',
    //    border:'1px solid',
        color:'#069'
    };
}
;
