function __Styles(){
    izmirColor ="#ff4a03";
    vanColor = "#4885ff";
}
;
