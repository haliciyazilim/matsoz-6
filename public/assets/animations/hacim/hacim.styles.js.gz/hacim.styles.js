function __Styles(){
    cubeStyle = {
        strokeColor:'#255b63',
        strokeWidth:1,
        fillColor:'#bfe8ef'
    };
    animationCubeStyle = {
        strokeColor:'#666',
        strokeWidth:1,
        fillColor:'#ddd'
    }
}
;
