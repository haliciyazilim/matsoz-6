function __Styles(){

    lettersStyle = {
        position:'absolute',
        top:'106px',
        left:'242px',
        width:'308px',
        height:'40px',
        fontSize:'24px',
        textAlign:'center',
        opacity:0
    };
};
