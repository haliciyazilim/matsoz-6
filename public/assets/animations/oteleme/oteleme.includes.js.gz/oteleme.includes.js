//= require ../benzer_cokgenler/benzer_cokgenler.common.js
//= require ./oteleme.styles.js
//= require ./oteleme.common.js
//= require ./oteleme.animation.js
//= require ./oteleme.interaction.js 
;