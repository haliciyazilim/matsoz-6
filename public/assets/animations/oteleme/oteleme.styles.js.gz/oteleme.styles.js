function __Styles(){
	/*
	* write your styles here without using 'var' definer
	*/
    interactionPathWrongStyle = {
        strokeColor:new RgbColor(1,0.3,0.3,0.7),
        fillColor:new RgbColor(1,0.5,0.5,0.7)
    }
    interactionPathCorrectStyle ={
        strokeColor:new RgbColor(0,0.7,0,0.8),
        fillColor:new RgbColor(0.3,0.7,0.3,0.8)
    }
}
;
