function __Styles(){

    firstDivStyle = {
        position:'absolute',
        top:'30px',
        left:'30px',
        width:'340px',
        height:'70px'
    };

    secondDivStyle = {
        position:'absolute',
        top:'120px',
        left:'30px',
        width:'340px',
        height:'70px'
    };

    thirdDivStyle = {
        position:'absolute',
        top:'75px',
        left:'400px',
        width:'360px',
        height:'70px'
    };

    questionDivStyle = {
        position:'absolute',
        top:'60px',
        left:'120px',
        width:'340px',
        height:'100px',
    //    border:'1px solid',
        fontSize:'24px'
    };

};
