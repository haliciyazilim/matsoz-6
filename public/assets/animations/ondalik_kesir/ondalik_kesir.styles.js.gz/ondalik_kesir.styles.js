function __Styles(){
    sayilarStrokeRenk="#9bd1d9";
    sayilarFillRenk="#f2fafc";
    tabloStrokeRenk="#255b63";
    tabloBirlerFillRenk="#ecf8fa";
    tabloBinlerFillRenk="#d9f1f5";
    tabloMilyonlarFillRenk="#bfe8ef";
    inputStrokeRenk="#9bd1d9";
}
;
