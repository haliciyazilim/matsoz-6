function __Styles(){


    animDivStyle = {
        position:'absolute',
        top:'40px',
        left:'180px',
        width:'180px',
        height:'80px',
        fontSize:'32px',
    //    border:'1px solid'
    };

    animDivStyle2 = {
        position:'absolute',
        top:'40px',
        left:'470px',
        width:'180px',
        height:'80px',
        fontSize:'32px',
        //    border:'1px solid'
    };

    questionDivStyle = {
        position:'absolute',
        top:'60px',
        left:'160px',
        width:'240px',
        height:'60px',
        fontSize:'32px'
    };

    answerDivStyle = {
        position:'absolute',
        top:'160px',
        left:'80px',
        width:'360px',
        height:'30px',
        fontSize:'24px',
        color:'#069',
        textAlign:'center',
        //    border:'1px solid'
    };
}
;
