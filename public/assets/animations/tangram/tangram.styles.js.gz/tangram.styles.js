function __Styles(){

    tangramDefaultColor = new RgbColor(0,0,0);

    animationDefaultColor = new RgbColor(0,0,0);

	animationColors = [];

    animationColors[0] = new RgbColor(0.871,0.345,0.345);
    animationColors[1] = new RgbColor(0.345,0.713,0.871);
    animationColors[2] = new RgbColor(0.290,0.807,0.349);
    animationColors[3] = new RgbColor(0.298,0.349,0.862);
    animationColors[4] = new RgbColor(0.871,0.729,0.345);
    animationColors[5] = new RgbColor(0.851,0.345,0.871);
    animationColors[6] = new RgbColor(0.447,0.447,0.447);

    interactionColors = [];
    interactionColors[0] = "#7c2f00";
    interactionColors[1] = "#004f7c";
    interactionColors[2] = "#78007c";
    interactionColors[3] = "#553e00";
    interactionColors[4] = "#355339";

    interactionSelectedColors = [];
    interactionSelectedColors[0] = "#632600";
    interactionSelectedColors[1] = "#003f63";
    interactionSelectedColors[2] = "#600063";
    interactionSelectedColors[3] = "#443200";
    interactionSelectedColors[4] = "#2a422e";

    correctAnswerBorder = new RgbColor(0.764,0.584,0.352);
}
;
