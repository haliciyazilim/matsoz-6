function __Styles(){
    animStrokeColors = "#000000";

    meterSquareColor = "#9b773d";
    decimeterSquareColor = "#c3ad8b";
    centimeterSquareColor = "#d7c9b1";
    millimeterSquareColor = "#ebe4d8";
    decameterSquareColor = "#74592e";
    hectometerSquareColor = "#4d3b1e";
    kilometerSquareColor = "#3e3018";

    questionDivStyle = {
        position:'absolute',
        top:'80px',
        left:'60px',
        width:'420px',
        height:'60px',
        fontSize:'24px'
    }
};
