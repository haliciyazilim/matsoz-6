//= require ./tam_sayi.styles.js
//= require ./tam_sayi.common.js
//= require ./tam_sayi.animation.js
//= require ./tam_sayi.interaction.js 
;