soruResimleri={
    soruAdedi:5,
    soru1R1:"/assets/animations/eslik/eslik_1_alt_1.png",
    soru1R2:"/assets/animations/eslik/eslik_1_alt_2.png",
    soru1R3:"/assets/animations/eslik/eslik_1_alt_3.png",
    soru1RC:"/assets/animations/eslik/eslik_1_Cevap.png",
    soru1RS:"/assets/animations/eslik/eslik_1_Soru.png",
    soru1DD:180,

    soru2R1:"/assets/animations/eslik/eslik_2_alt_1.png",
    soru2R2:"/assets/animations/eslik/eslik_2_alt_2.png",
    soru2R3:"/assets/animations/eslik/eslik_2_alt_3.png",
    soru2RC:"/assets/animations/eslik/eslik_2_Cevap.png",
    soru2RS:"/assets/animations/eslik/eslik_2_Soru.png",
    soru2DD:180,

    soru3R1:"/assets/animations/eslik/eslik_3_alt_1.png",
    soru3R2:"/assets/animations/eslik/eslik_3_alt_2.png",
    soru3R3:"/assets/animations/eslik/eslik_3_alt_3.png",
    soru3RC:"/assets/animations/eslik/eslik_3_Cevap.png",
    soru3RS:"/assets/animations/eslik/eslik_3_Soru.png",
    soru3DD:180,

    soru4R1:"/assets/animations/eslik/eslik_4_alt_1.png",
    soru4R2:"/assets/animations/eslik/eslik_4_alt_2.png",
    soru4R3:"/assets/animations/eslik/eslik_4_alt_3.png",
    soru4RC:"/assets/animations/eslik/eslik_4_Cevap.png",
    soru4RS:"/assets/animations/eslik/eslik_4_Soru.png",
    soru4DD:180,

    soru5R1:"/assets/animations/eslik/eslik_5_alt_1.png",
    soru5R2:"/assets/animations/eslik/eslik_5_alt_2.png",
    soru5R3:"/assets/animations/eslik/eslik_5_alt_3.png",
    soru5RC:"/assets/animations/eslik/eslik_5_Cevap.png",
    soru5RS:"/assets/animations/eslik/eslik_5_Soru.png",
    soru5DD:180



};
