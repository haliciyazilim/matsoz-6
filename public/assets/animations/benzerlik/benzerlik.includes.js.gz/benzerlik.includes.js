//= require ../benzer_cokgenler/benzer_cokgenler.common.js
//= require ./benzerlik.styles.js
//= require ./benzerlik.common.js
//= require ./benzerlik.animation.js
//= require ./benzerlik.interaction.js 
;