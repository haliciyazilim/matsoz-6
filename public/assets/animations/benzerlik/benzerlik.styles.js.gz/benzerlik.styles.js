function __Styles(){
	interactionBoundaryStyle = {
        strokeColor:'#fff'
    };
    interactionPathStyle = {
        strokeColor:'#000',
        strokeWidth:2
    };
//    interactionPathBoundsStyle = {
//        strokeColor:'#CCC'
//    };
    interactionCircleStyle = {
        strokeColor:new RgbColor(0,0,0,0),
        fillColor:new RgbColor(0,0,0,0)
    }

}
;
