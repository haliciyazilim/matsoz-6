function __Styles(){
	interactionBoundaryStyle = {
        strokeColor:'#fff'
    };
    interactionPathStyle = {
        strokeColor:'#000',
        strokeWidth:2
    };
//    interactionPathBoundsStyle = {
//        strokeColor:'#CCC'
//    };
    interactionCircleStyle = {
        strokeColor:new RgbColor(0,0,0,0.0),
        strokeWidth:25,
//        fillColor:new RgbColor(
//            parseInt("fd",16)/255,
//            parseInt("db",16)/255,
//            parseInt("80",16)/255,1.0)
        fillColor:new RgbColor(0,0,0,0.5)

    }

}
;
