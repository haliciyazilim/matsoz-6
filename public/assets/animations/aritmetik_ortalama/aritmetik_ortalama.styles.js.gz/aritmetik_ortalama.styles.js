function __Styles(){
    inputBoxColor = "black";
    inputBoxAnswerColor = "green";
}
;
