//= require ./aritmetik_ortalama.styles.js
//= require ./aritmetik_ortalama.common.js
//= require ./aritmetik_ortalama.animation.js
//= require ./aritmetik_ortalama.interaction.js 
;