function __Styles(){
    animStrokeColors = "#000000";

    literColor = "#0072ff";
    deciliterColor = "#66aaff";
    centiliterColor = "#99c7ff";
    milliliterColor = "#cce3ff";
    decaliterColor = "#0055bf";
    hectoliterColor = "#00397f";
    kiloliterColor = "#002e66";

    questionDivStyle = {
        position:'absolute',
        top:'80px',
        left:'120px',
        width:'340px',
        height:'60px',
        fontSize:'24px'
    }
}
;
