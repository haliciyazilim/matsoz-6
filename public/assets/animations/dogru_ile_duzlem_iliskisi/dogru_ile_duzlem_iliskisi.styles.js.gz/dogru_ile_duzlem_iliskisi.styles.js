function __Styles(){
    surfaceStyle = {
        fillColor: "f2c885",
        strokeWidth: 2,
        opacity:0.8
    };

    surfaceStyleLine = {
        strokeColor: "#8b5400",

        strokeWidth: 2
        //opacity:0
    };

    textStyle={
        fillColor:"black",
        opacity:0
    };

    noktaStyle = {
        strokeColor: "#8b5400",
        strokeWidth: 5
    };

    circleStyle={
        strokeColor: "#8b5400",
        fillColor: "#8b5400"
    }

    dikmeStyle={
        strokeColor: "#8b5400",
        fillColor: "#8b5400"
    }


    // uygualama

    dogruStyle={
        strokeColor:new RgbColor(1,0,0,0),
        strokeWidth:10

    }

    seciliStyle={
        strokeColor:new RgbColor(0,0,0,0.5),
        strokeWidth:4

    }

}
;
